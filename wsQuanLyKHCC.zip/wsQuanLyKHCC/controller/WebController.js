'use strict';
//require thu vien
const express = require('express');
const bodyParser = require('body-parser');
const crypto = require('crypto');
const mongoose = require('mongoose');
const bcryptjs = require('bcryptjs');
const moment = require('moment');

const excel4node = require('excel4node');
const exceljs = require('exceljs')
var xlstojson = require("xls-to-json-lc");
var xlsxtojson = require("xlsx-to-json-lc");

var async = require('async');
/* xu ly multer*/
var fs = require('fs');
var multer = require('multer');
var storage = multer.diskStorage({ //multers disk storage settings
        destination: function (req, file, cb) {
            cb(null, './uploads/')
        },
        filename: function (req, file, cb) {
            var datetimestamp = Date.now();
            cb(null, file.fieldname + '-' + datetimestamp + '.' + file.originalname.split('.')[file.originalname.split('.').length -1])
        }
});
var upload = multer({ //multer settings
        storage: storage,
        fileFilter : function(req, file, callback) { //file filter
        if (['xls', 'xlsx'].indexOf(file.originalname.split('.')[file.originalname.split('.').length-1]) === -1)
        {
            return callback(new Error('Wrong extension type'));
        }
        callback(null, true);
    }
}).single('file');
//require model
var HocVien = mongoose.model('HocVien');
var GiangVien = mongoose.model('GiangVien');
var Khoa = mongoose.model('Khoa');
var Lop = mongoose.model('Lop');
var DanhSachDiemDanh = mongoose.model('DanhSachDiemDanh');

/*
    Xu ly thong tin chung =================================
*/

//update ngay thi cho lop hoc
exports.updateNgayThi = function(req,res){
    var ma_lop = req.body.ma_lop;
    var nt_cc = req.body.ngay_thi_cc;
    var nt_cn = req.body.ngay_thi_cn;

    var now = moment().format('YYYY-MM-DD');
    var now_insert = moment().format('DD-MM-YYYY');
    // xu ly ngay thi chung chi
    if(nt_cc !=""){
        var date_cc = moment(moment(nt_cc, ["DD-MM-YYYY", "DD/MM/YYYY","DD.MM.YYYY"])).format('YYYY-MM-DD');
        if(date_cc<now){
            nt_cc = now_insert;
        }else{
            nt_cc = moment(moment(nt_cc, ["DD-MM-YYYY", "DD/MM/YYYY","DD.MM.YYYY"])).format('DD-MM-YYYY');
        }
    }
    //xu ly ngay thi chung nhan
    if(nt_cn!=""){
        var date_cn = moment(moment(nt_cn, ["DD-MM-YYYY", "DD/MM/YYYY","DD.MM.YYYY"])).format('YYYY-MM-DD');
        if(date_cn < now){
            nt_cn = now_insert;
        }else{
            nt_cn = moment(moment(nt_cn, ["DD-MM-YYYY", "DD/MM/YYYY","DD.MM.YYYY"])).format('DD-MM-YYYY');
        }
    }
    Lop.updateOne({ma_lop:ma_lop},{$set: {ngay_thi_cc:nt_cc,ngay_thi_cn:nt_cn}}, function(err,res1){
        if(err){
            // console.log(err);
            res.setHeader('Access-Control-Allow-Origin', '*');
            res.send("f");
        }else{
            // console.log(res1);
            res.setHeader('Access-Control-Allow-Origin', '*');
            res.send("t");
        }
    })         
}

//lay thong tin cua lop theo ma lop
exports.getlop = function(req,res){
    var ma_lop = req.body.ma_lop;
    //console.log("Mã lớp: "+ma_lop);
    Lop.find({ma_lop:ma_lop},function(err,data){
        if(err){
            res.setHeader('Access-Control-Allow-Origin', '*');
            res.send("f");
        }else{
            if(data.length>0){
                res.setHeader('Access-Control-Allow-Origin', '*');
                res.json(data);
            }else{
                res.setHeader('Access-Control-Allow-Origin', '*');
                res.send("f");
            }
        }

    });
}

// lay danh sach cac lop theo giang vien
exports.getdslop= function(req, res) {
  	var ma_gv = req.body.ma_gv;
    //console.log(req.body);
    Lop.aggregate([
        {$match: {ma_gv:ma_gv}},
        {$lookup: {
            from: 'HocVien',
            localField: 'ma_lop',
            foreignField: 'ma_lop',
            as: 'ma_lop'
            }
        },
        {$sort:
            {'ma_khoa_hoc': -1}
        }
        ],function (err,data) {

        if(err){
            res.send(err);
        }
        if(data.length>0){
            res.setHeader('Access-Control-Allow-Origin', '*');
            // console.log(data);
            res.json(data);
            // res.send("OK");
        }else{
            res.setHeader('Access-Control-Allow-Origin', '*');
            res.send("f");
        }

    });
};

//lay danh sach sinh vien theo lop
exports.getdshv = function(req,res){
    var ma_lop = req.body.ma_lop;
    // console.log("ID LOP: "+ma_lop);
    HocVien.find({ma_lop:ma_lop},{_id:false,matkhau_hv:false},function(err,data){
        if(err){
            // console.log(err);
            res.send("f");
        }else{
            // console.log("DSHV: "+data);
            if(data.length>0){
                res.json(data);
            }else{
                res.send("f");
            }
        }
    })
}
//update diem cho hoc vien
exports.UpdateDiemThi=function(req,res){
    var mahv = req.body.ma_hv;
    var lt_cc = req.body.lt_cc;
    var th_cc = req.body.th_cc;
    var lt_cn = req.body.lt_cn;
    var th_cn = req.body.th_cn;
    HocVien.find({ma_hv:mahv},function(err,data){
        if(err) throw err
        if(data.length<0){
            res.send("f");
        }else{
            var thi_cc = data[0].thi_cc;
            var thi_cn = data[0].thi_cn;
            if(!thi_cc){
                lt_cc="";
                th_cc="";
            }
            if(!thi_cn){
                lt_cn="";
                th_cn=""
            }
            HocVien.updateOne({ma_hv:mahv},
                    {$set:{diemthi_lt_cc:lt_cc,diemthi_th_cc:th_cc,diemthi_lt_cn:lt_cn,diemthi_th_cn:th_cn}},
                function(err_up,res_up){
                    if(err_up){
                        console.log(err_up);
                        res.send("f");
                    }
                    res.send("t");
                })
        }
    })
}
//lay file danh sach excel sinh vien
exports.exportExcelDshv = function(req,res){
    var ma_lop = req.query.ma_lop;
    var workbook = new excel4node.Workbook();

    var style = workbook.createStyle({
      font: {
        size: 16,
        bold:true
      }
    });
    var worksheet = workbook.addWorksheet('DSHV');

    HocVien.find({ma_lop:ma_lop},{_id:false,matkhau_hv:false},function(err, data){
        
        if(err) throw err;
            worksheet.cell(1, 1, 1, 8,true).string('Danh Sách Học Viên Lớp '+ma_lop).style(style);
            worksheet.cell(2, 1).string('Mã Học Viên').style({font:{bold:true}});
            worksheet.cell(2, 2).string('Họ Tên').style({font:{bold:true}});
            worksheet.cell(2, 3).string('Giới Tính').style({font:{bold:true}});
            worksheet.cell(2, 4).string('Ngày Sinh').style({font:{bold:true}});
            worksheet.cell(2, 5).string('Quê Quán').style({font:{bold:true}});
            worksheet.cell(2, 6).string('CMND').style({font:{bold:true}});
            worksheet.cell(2, 7).string('Email').style({font:{bold:true}});
            worksheet.cell(2, 8).string('Điện Thoại').style({font:{bold:true}});
            worksheet.cell(2, 9).string('MSSV').style({font:{bold:true}});
            var m=3;
            for(var i=0; i < data.length ; i++){
                var ns = data[i].ngaysinh_hv;
                var ngaysinh = moment(ns).format("DD-MM-YYYY");
                worksheet.cell(m, 1).string(data[i].ma_hv);
                worksheet.cell(m, 2).string(data[i].hoten_hv);
                worksheet.cell(m, 3).string(data[i].gioitinh_hv);
                worksheet.cell(m, 4).string(ngaysinh);
                worksheet.cell(m, 5).string(data[i].quequan_hv);
                worksheet.cell(m, 6).string(data[i].cmnd_hv);
                worksheet.cell(m, 7).string(data[i].email_hv);
                worksheet.cell(m, 8).string(data[i].sdt_hv);
                worksheet.cell(m, 9).string(data[i].mssv);
                m++;
            }
            res.setHeader('Content-disposition', 'attachment; filename=' + "danhsach.xlsx");
            res.setHeader('Content-type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            workbook.write('danhsach.xlsx', res);
    })
}
//lay file danh sach excel sinh vien thi chung chi
exports.exportDshvCC = function(req,res){
    var ma_lop = req.query.ma_lop;
    var workbook = new excel4node.Workbook();

    var style = workbook.createStyle({
      font: {
        size: 16,
        bold:true
      }
    });
    var worksheet = workbook.addWorksheet('DSHV-ChungChi');

    HocVien.find({ma_lop:ma_lop,thi_cc:true},{_id:false,matkhau_hv:false},function(err, data){
        
        if(err) throw err;
            worksheet.cell(1, 1, 1, 8,true).string('Danh Sách Học Viên Thi Chứng Chỉ Lớp '+ma_lop).style(style);
            worksheet.cell(2, 1).string('Mã Học Viên').style({font:{bold:true}});
            worksheet.cell(2, 2).string('Họ Tên').style({font:{bold:true}});
            worksheet.cell(2, 3).string('Giới Tính').style({font:{bold:true}});
            worksheet.cell(2, 4).string('Ngày Sinh').style({font:{bold:true}});
            worksheet.cell(2, 5).string('Quê Quán').style({font:{bold:true}});
            worksheet.cell(2, 6).string('CMND').style({font:{bold:true}});
            worksheet.cell(2, 7).string('Email').style({font:{bold:true}});
            worksheet.cell(2, 8).string('Điện Thoại').style({font:{bold:true}});
            worksheet.cell(2, 9).string('MSSV').style({font:{bold:true}});
            var m=3;
            for(var i=0; i < data.length ; i++){
                var ns = data[i].ngaysinh_hv;
                var ngaysinh = moment(ns).format("DD-MM-YYYY");
                worksheet.cell(m, 1).string(data[i].ma_hv);
                worksheet.cell(m, 2).string(data[i].hoten_hv);
                worksheet.cell(m, 3).string(data[i].gioitinh_hv);
                worksheet.cell(m, 4).string(ngaysinh);
                worksheet.cell(m, 5).string(data[i].quequan_hv);
                worksheet.cell(m, 6).string(data[i].cmnd_hv);
                worksheet.cell(m, 7).string(data[i].email_hv);
                worksheet.cell(m, 8).string(data[i].sdt_hv);
                worksheet.cell(m, 9).string(data[i].mssv);
                m++;
            }
            res.setHeader('Content-disposition', 'attachment; filename=' + "danhsach.xlsx");
            res.setHeader('Content-type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            workbook.write('danhsach.xlsx', res);
    })
}
//lay file danh sach excel sinh vien thi chung nhan
exports.exportDshvCN = function(req,res){
    var ma_lop = req.query.ma_lop;
    var workbook = new excel4node.Workbook();

    var style = workbook.createStyle({
      font: {
        size: 16,
        bold:true
      }
    });
    var worksheet = workbook.addWorksheet('DSHV-ChungNhan');

    HocVien.find({ma_lop:ma_lop,thi_cn:true},{_id:false,matkhau_hv:false},function(err, data){
        
        if(err) throw err;
            worksheet.cell(1, 1, 1, 8,true).string('Danh Sách Học Viên Thi Chứng Nhận Lớp '+ma_lop).style(style);
            worksheet.cell(2, 1).string('Mã Học Viên').style({font:{bold:true}});
            worksheet.cell(2, 2).string('Họ Tên').style({font:{bold:true}});
            worksheet.cell(2, 3).string('Giới Tính').style({font:{bold:true}});
            worksheet.cell(2, 4).string('Ngày Sinh').style({font:{bold:true}});
            worksheet.cell(2, 5).string('Quê Quán').style({font:{bold:true}});
            worksheet.cell(2, 6).string('CMND').style({font:{bold:true}});
            worksheet.cell(2, 7).string('Email').style({font:{bold:true}});
            worksheet.cell(2, 8).string('Điện Thoại').style({font:{bold:true}});
            worksheet.cell(2, 9).string('MSSV').style({font:{bold:true}});
            var m=3;
            for(var i=0; i < data.length ; i++){
                var ns = data[i].ngaysinh_hv;
                var ngaysinh = moment(ns).format("DD-MM-YYYY");
                worksheet.cell(m, 1).string(data[i].ma_hv);
                worksheet.cell(m, 2).string(data[i].hoten_hv);
                worksheet.cell(m, 3).string(data[i].gioitinh_hv);
                worksheet.cell(m, 4).string(ngaysinh);
                worksheet.cell(m, 5).string(data[i].quequan_hv);
                worksheet.cell(m, 6).string(data[i].cmnd_hv);
                worksheet.cell(m, 7).string(data[i].email_hv);
                worksheet.cell(m, 8).string(data[i].sdt_hv);
                worksheet.cell(m, 9).string(data[i].mssv);
                m++;
            }
            res.setHeader('Content-disposition', 'attachment; filename=' + "danhsach.xlsx");
            res.setHeader('Content-type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            workbook.write('danhsach.xlsx', res);
    })
}
//lay thong tin 1 hv
exports.gethv = function(req, res) {
  var ma_hv = req.query.ma_hv;
  HocVien.find({ma_hv:ma_hv},{_id:false,matkhau_hv:false,mssv:false,cmnd_hv:false},function(err, data) {
    if (err){
        res.send(err);
    }else{
        if(data.length>0){
            res.json(data);
        }else{
            res.send("f");
        }
    }   
  });
};

//lay diem danh cua 1 hv
exports.getDiemDanh = function(req, res) {
  var ma_hv = req.query.ma_hv;
  DanhSachDiemDanh.find({ma_hv:ma_hv},function(err, data) {
    if (err){
        res.send(err);
    }else{
        if(data.length>0){
            res.json(data);
        }else{
            res.send("f");
        }
    }   
  }).sort({ngay:-1});
};

//lay thong tin 1 buoi diem danh
exports.getThongTinDiemDanh = function(req, res) {
  var id = req.body.ma;
  // console.log(id);
  DanhSachDiemDanh.find({_id:id},function(err, data) {
    if (err){
        res.send(err);
    }else{
        if(data.length>0){
            res.json(data);
        }else{
            res.send("f");
        }
    }   
  }).sort({ngay:-1});
};
//update diem danh
exports.updateDiemDanh= function(req,res){
    var id = req.body.ma;
    var diem = req.body.diem;
    var nx = req.body.nx;
    DanhSachDiemDanh.updateOne({_id:id},{$set: {diem_danhgia:diem,nhanxet:nx}}, function(err,res1){
        if(err){
            // console.log(err);
            res.send("f");
        }else{
            // console.log(res1);
            res.send("t");
        }
    })
}
/*
    Xu ly import/export ========================================
*/

//export bang diem mau
exports.exportBangDiemMauThiCC = function(req,res){
    var ma = req.query.ma_lop;

    var wb = new excel4node.Workbook();

    var ws = wb.addWorksheet('bangdiem_chungchi');

    var style = wb.createStyle({
      font: {
        size: 14,
        bold:true
      }
    });
    HocVien.find({ma_lop:ma},function(err,data){
        if(err){
            console.log(err);
            // res.send("f");
        }else{
            if(data.length<0){
                wb.write('bangdiem_thi_chungchi.xlsx', res);
            }else{
                ws.cell(1, 1).string('Mã học viên').style(style); //Hàng 1 - Cột 1
                ws.cell(1, 2).string('Họ tên').style(style);  //Hàng 1 - Cột 2
                ws.cell(1, 3).string('Lý thuyết').style(style);
                ws.cell(1, 4).string('Thực hành').style(style);
                var m=2;
                for(var i=0; i < data.length ; i++){
                    ws.cell(m, 1).string(data[i].ma_hv);
                    ws.cell(m, 2).string(data[i].hoten_hv);
                    m++;
                }
                wb.write('bangdiem_thi_chungchi.xlsx', res);                
            }
        }
    })
}
//export bang diem mau
exports.exportBangDiemMauThiCN = function(req,res){
    var ma = req.query.ma_lop;

    var wb = new excel4node.Workbook();

    var ws = wb.addWorksheet('bangdiem_chungnhan');

    var style = wb.createStyle({
      font: {
        size: 14,
        bold:true
      }
    });
    HocVien.find({ma_lop:ma},function(err,data){
        if(err){
            console.log(err);
            // res.send("f");
        }else{
            if(data.length<0){
                wb.write('bangdiem_thi_chungnhan.xlsx', res);
            }else{
                ws.cell(1, 1).string('Mã học viên').style(style); //Hàng 1 - Cột 1
                ws.cell(1, 2).string('Họ tên').style(style);  //Hàng 1 - Cột 2
                ws.cell(1, 3).string('Lý thuyết').style(style);
                ws.cell(1, 4).string('Thực hành').style(style);
                var m=2;
                for(var i=0; i < data.length ; i++){
                    ws.cell(m, 1).string(data[i].ma_hv);
                    ws.cell(m, 2).string(data[i].hoten_hv);
                    m++;
                }
                wb.write('bangdiem_thi_chungnhan.xlsx', res);                
            }
        }
    })
}
//import bang diem mau
exports.importBangDiem = function(req,res){
        var exceltojson; //Initialization

        upload(req,res,function(err){
        if(err){
            res.send("f");
            return;
        }
        /** Multer gives us file info in req.file object */
        if(!req.file){
            res.send("n"); // no file passed
            return;
        }
        // console.log(req.file.path);
        try {
            var wb = new exceljs.Workbook();
            wb.xlsx.readFile(req.file.path).then(function(){
                var ws = wb.getWorksheet(1);
                console.log(ws.name);
                var ws_name=ws.name;
                if(ws_name=="bangdiem_chungchi"){
                    var sh = wb.getWorksheet(ws_name);
                    console.log("Tổng số row: "+sh.rowCount);
                    var i = 2;
                    async.whilst(
                      function() { return i <= sh.rowCount; },
                      function(callback) {
                        //delete upsertData._id;
                        HocVien.updateOne(
                          { ma_hv: sh.getRow(i).getCell('A').value},
                          {
                            $set : {
                              diemthi_lt_cc:sh.getRow(i).getCell('C').value,
                              diemthi_th_cc:sh.getRow(i).getCell('D').value
                            }
                          },
                          { upsert: true},
                          function(err,data) {
                            if (err) callback(err);
                            console.log(sh.getRow(i).getCell('A').value+" "+sh.getRow(i).getCell('C').value);
                            console.log(data);
                            i++;
                            callback();
                          }
                        );

                      },
                      function(err) {
                        if (err) console.log(err);
                        else{
                          // done;
                            res.send("t");
                        }
                      }
                    ); // end async whilse
                }else if(ws_name=="bangdiem_chungnhan"){
                    var sh = wb.getWorksheet(ws_name);
                    console.log("Tổng số row: "+sh.rowCount);
                    var i = 2;
                    async.whilst(
                      function() { return i <= sh.rowCount; },
                      function(callback) {
                        //delete upsertData._id;
                        HocVien.updateOne(
                          { ma_hv: sh.getRow(i).getCell('A').value},
                          {
                            $set : {
                              diemthi_lt_cn:sh.getRow(i).getCell('C').value,
                              diemthi_th_cn:sh.getRow(i).getCell('D').value
                            }
                          },
                          { upsert: true},
                          function(err,data) {
                            if (err) callback(err);
                            console.log(sh.getRow(i).getCell('A').value+" "+sh.getRow(i).getCell('C').value);
                            console.log(data);
                            i++;
                            callback();
                          }
                        );

                      },
                      function(err) {
                        if (err) console.log(err);
                        else{
                          // done;
                            res.send("t");
                        }
                      }
                    ); // end async whilse
                }else{
                    res.send("c");
                }
                try {
                    fs.unlinkSync(req.file.path); //xoa file
                } catch(e) {
                        //error deleting the file
                }
            }); // wb.readFile
        } catch (e){
            res.send("c"); //loi file bi hu
        }
    });
}
/*
    Xu ly thong tin giang vien =================================
*/

//dang nhap cho gv
exports.dangnhap_gv = function(req, res) {
    var ma_gv = req.body.ma_gv;
    var matkhau = req.body.matkhau_gv;
    // console.log("Mã: "+ma_gv+" pass: "+matkhau);
    GiangVien.find({ma_gv : ma_gv,matkhau_gv : matkhau}, function(err, giangvien) {
        if(err){
            res.setHeader('Access-Control-Allow-Origin', '*');
            res.send("f"); // fact: the account is not exit
        }else{
            if(giangvien.length>0){
                res.setHeader('Access-Control-Allow-Origin', '*');
                res.json(giangvien);
                // res.send("OK");
            }else{
                res.setHeader('Access-Control-Allow-Origin', '*');
                res.send("f");
            }
        }
    });
};
//lay thong tin gv
exports.thongtin_gv = function(req,res){
    var ma_gv = req.body.ma_gv;
    GiangVien.find({ma_gv:ma_gv},function(err,giangvien){
        if(err){
            res.send("f");
        }else{
            res.send(giangvien);
        }
    })
}
//cap nhat thong tin giang vien
exports.capnhat_ttgv = function(req,res){
    var ma = req.body.ma_gv;
    var ht = req.body.hoten;
    var cmnd = req.body.cmnd;
    var email = req.body.email;
    var sdt = req.body.sdt;
    GiangVien.updateOne({ma_gv:ma},{$set: {hoten_gv:ht,cmnd_gv:cmnd,email_gv:email,sdt_gv:sdt}}, function(err,res1){
        if(err){
            console.log(err);
            res.send("f");
        }else{
            console.log(res1);
            res.send("t");
        }
    })    
}
//cap nhat thong tin giang vien
exports.capnhat_mkgv = function(req,res){
    var ma = req.body.ma_gv;
    var mk= req.body.mk;
    var mk1= req.body.mk1;
    GiangVien.find({ma_gv:ma,matkhau_gv:mk},function(err,giangvien){
        if(err){
            res.send("f");
        }else{
            if(giangvien.length>0){
                GiangVien.updateOne({ma_gv:ma},{$set: {matkhau_gv:mk1}}, function(err,res1){
                    if(err){
                        // console.log(err);
                        res.send("f");
                    }else{
                        // console.log(res1);
                        res.send("t");
                    }
                }) 
            }else{
               res.send("f"); 
            }
        }
    })   
}