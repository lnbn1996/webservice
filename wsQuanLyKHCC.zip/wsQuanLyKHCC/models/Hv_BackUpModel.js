var mongoose = require('mongoose');
var validator = require('validator');
var Schema = mongoose.Schema;

var Hv_BackUpSchema = new Schema({
    ma_hv: { type:String },
    matkhau_hv: {type: String},
	hoten_hv: { type: String },
	gioitinh_hv: { type: String },
	ngaysinh_hv: { type: Date },
	quequan_hv: { type:String },
	cmnd_hv: {type:String},/* minlength: 9,maxlength: 9 },*/
	email_hv: { type:String},/*, validate: (value) => {
      return validator.isEmail(value)
    	}
	},*/
	sdt_hv: { type:String},/*, minlength: 10,maxlength: 11 },*/
	mssv: { type:String },
	ma_lop: { type:String },
	ma_khoa_hoc: { type:String },
    thi_cc : { type:Boolean },
    thi_cn : { type:Boolean },
    diemthi_lt_cc : {type: Number, min: 1, max: 10},
    diemthi_th_cc : {type: Number, min: 1, max: 10},
    diemthi_lt_cn : {type: Number, min: 1, max: 10},
    diemthi_th_cn : {type: Number, min: 1, max: 10},
    ngay_xoa : {type: Date}
});

//module.exports = mongoose.model('hocvien',hocvienSchema);
module.exports = mongoose.model('Hv_BackUp',Hv_BackUpSchema,'Hv_BackUp');