var mongoose = require('mongoose');
var validator = require('validator');
var Schema = mongoose.Schema;

var KhoaSchema = new Schema({
	ma_khoa_hoc: { type: Number },
	ngaykhaigiang: { type: Date },
	ngayketthuc: {type:Date}
});

module.exports = mongoose.model('Khoa',KhoaSchema,'Khoa');