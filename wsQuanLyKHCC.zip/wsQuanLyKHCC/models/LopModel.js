var mongoose = require('mongoose');
var validator = require('validator');
var Schema = mongoose.Schema;

var LopSchema = new Schema({
    ma_lop: { type: String,trim: true, Required: true },
    lop_246: {type: Number }, // 1 - 246 : 0 - 357
	ma_khoa_hoc: { type: Number },
	loailop: {type: Number }, // 1 - lopcanban : 0 - lopnangcao
	ma_gv: { type: String },
	ngay_thi_cc: { type: String },
	ngay_thi_cn: { type: String },
	ngay_nhan_bang: { type:String }
});

module.exports = mongoose.model('Lop',LopSchema,'Lop');