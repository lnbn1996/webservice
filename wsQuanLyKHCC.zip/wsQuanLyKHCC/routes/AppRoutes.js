'use strict';
const auth = require('basic-auth');
const jwt = require('jsonwebtoken');
module.exports = function(app){

	/*
		App Hoc Vien
	*/

	var hocvien = require('../controller/AppController.js');
	//Lay info cb cua hoc vien
	app.route('/hocvien/:ma_hv').get(hocvien.gethocvien);
	//Lay info tong quat hoc tap cua hoc vien
	app.route('/songay_hv/:ma_hv').get(hocvien.getSoNgayHoc);
	//Lay tong so diem danh gia cua hoc vien
	app.route('/tongdiem_hv/:ma_hv').get(hocvien.getTongDiemDanhGia);
	//Login cho hoc vien
	app.route('/dangnhap_hv').post(hocvien.dangnhap_hv);
	//Doi mat khau cho hoc vien
	app.route('/doimk_hv').post(hocvien.doimk_hv);
	//get info hv de cho hv cap nhat
	app.route('/getinfohv/:ma_hv').get(hocvien.getinfohv);
	//Doi mat khau cho hoc vien
	app.route('/updateinfohv').post(hocvien.updateinfohv);
	//get info lop
	app.route('/getinfolop/:ma_lop').get(hocvien.getinfolop);
	app.route('/getdiemhv/:ma_lop').get(hocvien.getdiemhv);

	/*
		Web - Giang day role
	*/

	var webRoute = require('../controller/WebController.js');
	//update ngay thi
	app.route('/update_ngay_thi').post(webRoute.updateNgayThi);
	//lay thong tin all lop
	app.route('/dslop').post(webRoute.getdslop);
	//lay thong tin 1 lop
	app.route('/getlop').post(webRoute.getlop);
	//lay ds hv
	app.route('/dshv').post(webRoute.getdshv);
	//lay tt hv
	app.route('/gethv/:ma_hv').get(webRoute.gethv);
	//lay tt diem danh
	app.route('/getdiemdanh/:ma_hv').get(webRoute.getDiemDanh);
	//lay tt 1 buoi diem danh
	app.route('/getttdd').post(webRoute.getThongTinDiemDanh);
	//lay tt 1 buoi diem danh
	app.route('/updatediemdanh').post(webRoute.updateDiemDanh);
	//update diem thi
	app.route('/update_diem_thi').post(webRoute.UpdateDiemThi);
	//dang nhap cho giang vien
	app.route('/dangnhap_gv').post(webRoute.dangnhap_gv);
	//lay thong tin gv
	app.route('/ttgv').post(webRoute.thongtin_gv);
	//cap nhat thong tin gv
	app.route('/capnhat_ttgv').post(webRoute.capnhat_ttgv);
	//cap nhat thong tin gv
	app.route('/capnhat_mkgv').post(webRoute.capnhat_mkgv);
	//====import - export
	app.route('/export_bang_diem_mau_thi_cc/:ma_lop').post(webRoute.exportBangDiemMauThiCC);
	app.route('/export_bang_diem_mau_thi_cn/:ma_lop').post(webRoute.exportBangDiemMauThiCN);
	app.route('/import_bang_diem').post(webRoute.importBangDiem);
	//lay file excel dshv
	app.route('/exceldshv/:ma_lop').post(webRoute.exportExcelDshv);
	//lay file excel dshv thi chung chi
	app.route('/exportDshvCC/:ma_lop').post(webRoute.exportDshvCC);
	//lay file excel dshv thi chung nhan
	app.route('/exportDshvCN/:ma_lop').post(webRoute.exportDshvCN);

	/*
		Web - Quan ly role
	*/

	var qlyRoute = require('../controller/WebqlyController.js');
	//lay ds khoa
	app.route('/dskhoa').get(qlyRoute.getkhoa);
	//lay ds lop theo khoa
	app.route('/get_cac_lop').get(qlyRoute.get_cac_lop);
	//xoa hoc hoc
	app.route('/delkhoahoc').post(qlyRoute.delkhoaHoc);
	//update ngay khai giang
	app.route('/update_khoa').post(qlyRoute.updateKhoa);
	//get thong tin 1 khoa
	app.route('/get_tt_khoa').post(qlyRoute.get_tt_khoa);
	//get thong tin 1 khoa
	app.route('/insert_khoa').post(qlyRoute.insert_khoa);
	// lay ds lop theo kkhoa
	app.route('/dslop_khoa').post(qlyRoute.dslop_khoa);
	//get ds gv
	app.route('/get_ds_gv').get(qlyRoute.get_ds_gv);
	//get ds gv cho select option
	app.route('/get_dsgv_SelectOption').get(qlyRoute.get_dsgv_SelectOption);
	//update thong tin lop
	app.route('/update_lop').post(qlyRoute.updateLop);
	//them lop
	app.route('/them_lop').post(qlyRoute.themLop);
	//xoa lop
	app.route('/dellop').post(qlyRoute.delLop);
	//export dssv mau
	app.route('/export_dssv_mau/:ma_lop_ma_khoa').post(qlyRoute.exportDshvMau);
	app.route('/import_danhsachv').post(qlyRoute.importDanhSachHv);
	//get 1 hoc vien
	app.route('/ql_gethv').post(qlyRoute.ql_getHv);
	//update hoc vien
	app.route('/update_ql_hv').post(qlyRoute.update_ql_hv);
	// them mot hoc vien
	app.route('/them_mot_hv').post(qlyRoute.them_mot_hv);
	//xoa hoc vien
	app.route('/delhv').post(qlyRoute.delHv);
	//cap nhat thong tin gv phia quan ly
	app.route('/ql_capnhat_ttgv').post(qlyRoute.ql_capnhat_ttgv);
	//them giang vien
	app.route('/ql_them_gv').post(qlyRoute.ql_them_gv);
	//xoa giang vien
	app.route('/delgv').post(qlyRoute.delGv);
};